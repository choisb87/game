d1.b
