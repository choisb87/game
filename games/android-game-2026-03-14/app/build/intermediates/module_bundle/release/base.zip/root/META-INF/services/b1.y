c1.b
